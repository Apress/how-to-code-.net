using System;
using System.Reflection;
using System.Collections;
using System.IO;
using Devspace.Commons.Tracer;
using Devspace.Commons.Automators;
using System.Security.Policy;
using System.Security.Permissions;

namespace Devspace.Commons.Loader {
    public abstract class AssemblyLoader2 : IFactory< Identifier> {
        public AssemblyLoader2() {
        }
        
        #region data members
        protected AppDomain _unloadable;
        protected string _applicationName;
        protected string _remoteDomainAppDirectory;
        protected string _appRelativeSearchPath;
        protected bool _shadowCopyFiles;
        protected Evidence _securityInfo;
        protected AppDomainInitializer _initializer;
        protected string[] _initializerArgs;
        #endregion
        
        public static void LocalAppDomainInitialize(string[] args) {
        }
        
        #region overridable methods
        protected virtual string GetRelativeSearchPath() {
            return "";
        }
        protected virtual string GetAppDomainBaseDirectory() {
            return AppDomain.CurrentDomain.BaseDirectory;
        }
        protected virtual bool GetShadowCopyFiles() {
            return false;
        }
        protected abstract string GetAppDomainName();
        protected virtual Evidence GetSecurityInfo() {
            return AppDomain.CurrentDomain.Evidence;
        }
        protected AppDomainInitializer GetInitializerFunction() {
            return new AppDomainInitializer(AssemblyLoader2.LocalAppDomainInitialize);
        }
        protected string[] GetInitializerArgs() {
            return new string[]{ };
        }
        protected virtual AppDomain CreateApplicationDomain() {
            return AppDomain.CreateDomain(_applicationName, _securityInfo, _remoteDomainAppDirectory,
                                          _appRelativeSearchPath, _shadowCopyFiles,
                                          _initializer, _initializerArgs);
        }
        #endregion
        
        #region private methods
        private void pLoad() {
            _applicationName = GetAppDomainName();
            _remoteDomainAppDirectory = GetAppDomainBaseDirectory();
            _appRelativeSearchPath = GetRelativeSearchPath();
            _shadowCopyFiles = GetShadowCopyFiles();
            _securityInfo = GetSecurityInfo();
            _unloadable = CreateApplicationDomain();
            _initializer = GetInitializerFunction();
            _initializerArgs = GetInitializerArgs();
        }
        private void pUnload() {
            AppDomain.Unload(_unloadable);
            _unloadable = null;
        }
        #endregion
        
        #region public access methods
        private RemoteLoader _remoteLoader;
        public AssemblyLoader2 Load() {
            pLoad();
            _remoteLoader = (RemoteLoader)_unloadable.CreateInstanceAndUnwrap(
                typeof( RemoteLoader).Assembly.FullName, typeof( RemoteLoader).FullName);
            return this;
        }
        public AssemblyLoader2 Unload() {
            pUnload();
            _remoteLoader = null;
            return this;
        }
        public bool CanCreate(Identifier identifier) {
            if (identifier.DoesExist(Identifier.ID_type) &&
                identifier.DoesExist(Identifier.ID_assembly)) {
                return true;
            }
            return false;
        }
        
        public ObjectType Instantiate<ObjectType>(Identifier identifier) where ObjectType : class {
            if (identifier.DoesExist(Identifier.ID_type) &&
                identifier.DoesExist(Identifier.ID_assembly)) {
                string typeIdentifier = identifier[Identifier.ID_type];
                string assemblyIdentifier = identifier[Identifier.ID_assembly];
                
                return _unloadable.CreateInstanceAndUnwrap(assemblyIdentifier, typeIdentifier) as ObjectType;
            }
            return default( ObjectType);
        }
        public override string ToString() {
            return new ToStringTracer()
                .Start(this)
                .Variable("application name", _applicationName)
                .Variable("Application directory", AppDomain.CurrentDomain.SetupInformation.ApplicationBase)
                .Variable("Application bin directory", AppDomain.CurrentDomain.SetupInformation.PrivateBinPath)
                .StartArray("Loaded Assemblies")
                .Delegated(new ToStringTracerDelegate(
                               delegate(ToStringTracer instance) {
                                   foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies()) {
                                       instance.Variable("Assembly", assembly.FullName);
                                   }
                               }
                           ))
                .EndArray()
                .Delegated(new ToStringTracerDelegate(
                               delegate(ToStringTracer instance) {
                                   if (_remoteLoader != null) {
                                       instance.Embedded(_remoteLoader.ToString());
                                   }
                               }))
                .End();
        }
        #endregion
    }
}
