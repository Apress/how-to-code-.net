using System;
using System.Reflection;
using System.Collections;
using System.IO;
using Devspace.Commons.Tracer;
using Devspace.Commons.Automators;
using System.Security.Policy;
using System.Security.Permissions;

namespace Devspace.Commons.Loader {
    public class AppDomainHelpers {
        public static StrongName CreateStrongName(Assembly assembly) {
            if (assembly == null) {
                throw new ArgumentNullException("assembly");
            }
            
            AssemblyName assemblyName = assembly.GetName();
            
            byte[] publicKey = assemblyName.GetPublicKey();
            if (publicKey == null || publicKey.Length == 0)
                throw new InvalidOperationException("Assembly is not strongly named");
            
            StrongNamePublicKeyBlob keyBlob = new StrongNamePublicKeyBlob(publicKey);
            
            return new StrongName(keyBlob, assemblyName.Name, assemblyName.Version);
        }
    }
    
    #region AddDomainsBase
    public abstract class AppDomainsBase {
        protected AppDomain _appDomain;
        protected string _applicationName;
        protected string _remoteDomainAppDirectory;
        
        protected abstract void AssignPrivateBinPath(AppDomainSetup setup);
        protected abstract void AssignShawdowPath(AppDomainSetup setup, bool shawdowCopyAll);
        
        protected void AssignApplicationName(string applicationName) {
            _applicationName = applicationName;
        }
        
        protected virtual void pLoad(bool shadowCopyAll) {
            AppDomainSetup setup = new AppDomainSetup();
            
            setup.ApplicationBase = _remoteDomainAppDirectory;
            AssignPrivateBinPath(setup);
            AssignShawdowPath(setup, shadowCopyAll);
            setup.ApplicationName = _applicationName;
            
            _appDomain = CreateApplicationDomain(setup);
        }
        protected virtual AppDomain CreateApplicationDomain(AppDomainSetup setup) {
            return AppDomain.CreateDomain(_applicationName, null, setup);
        }
        protected virtual void pUnload() {
            AppDomain.Unload(_appDomain);
            _appDomain = null;
        }
        public override string ToString() {
            return new ToStringTracer()
                .Start(this)
                .Variable("application name", _applicationName)
                .Variable("Application directory", AppDomain.CurrentDomain.SetupInformation.ApplicationBase)
                .Variable("Application bin directory", AppDomain.CurrentDomain.SetupInformation.PrivateBinPath)
                .StartArray("Loaded Assemblies")
                .Delegated(new ToStringTracerDelegate(
                               delegate(ToStringTracer instance) {
                                   foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies()) {
                                       instance.Variable("Assembly", assembly.FullName);
                                   }
                               }
                           ))
                .EndArray()
                .End();
        }
    }
    #endregion
    
    public class Identifier {
        public const string ID_assembly = "assembly";
        public const string ID_type = "type";
        
        private Hashtable _propBag = new Hashtable();
        
        public Identifier(string identifier) {
            _propBag[ID_type] = identifier;
        }
        public Identifier(string assembly, string identifier) {
            _propBag[ID_assembly] = assembly;
            _propBag[ID_type] = identifier;
        }
        public Identifier() {
        }
        public string this[string key] {
            get {
                return (string)_propBag[key];
            }
            set {
                _propBag[key] = value;
            }
        }
        public bool DoesExist(string key) {
            return _propBag.ContainsKey(key);
        }
    }
    
    public class AssemblyLoader : AppDomainsBase, IFactory< Identifier> {
        
        private RemoteLoader _remoteLoader;
        
        public AssemblyLoader(string applicationName) {
            AssignApplicationName(applicationName);
            _remoteDomainAppDirectory = AppDomain.CurrentDomain.BaseDirectory;
        }
        
        private bool _shadowCopy;
        public bool ShadowCopy {
            get {
                return _shadowCopy;
            }
            set {
                _shadowCopy = value;
            }
        }
        
        private ArrayList _paths = new ArrayList();
        private ArrayList _shadowPaths = new ArrayList();
        private string _cacheDirectory;
        
        public string[] Paths {
            get {
                string[] retval = new string[_paths.Count];
                for (int c1 = 0; c1 < _paths.Count; c1++) {
                    retval[c1] = (string)(_paths[c1]);
                }
                return retval;
            }
        }
        
        public string[] ShadowPaths {
            get {
                string[] retval = new string[_shadowPaths.Count];
                for (int c1 = 0; c1 < _shadowPaths.Count; c1++) {
                    retval[c1] = (string)(_shadowPaths[c1]);
                }
                return retval;
            }
        }
        public string CacheDirectory {
            get {
                return _cacheDirectory;
            }
            set {
                _cacheDirectory = value;
            }
        }
        public AssemblyLoader AssignRemoteAppDirectory(string path) {
            _remoteDomainAppDirectory = path;
            return this;
        }
        public AssemblyLoader AppendPath(string path) {
            _paths.Add(path);
            return this;
        }
        public AssemblyLoader AppendPath(string path, bool isShadow) {
            _paths.Add(path);
            if (isShadow) {
                AppendShadowPath(path);
            }
            return this;
        }
        public void AppendShadowPath(string path) {
            _shadowPaths.Add(path);
        }
        public void RemovePath(string inpPath) {
            _paths.Remove(inpPath);
        }
        protected override void AssignPrivateBinPath(AppDomainSetup setup) {
            string fullpath = "";
            foreach (string path in _paths) {
                fullpath += path + Path.PathSeparator;
            }
            setup.PrivateBinPath = fullpath;
        }
        protected override void AssignShawdowPath(AppDomainSetup setup, bool shawdowCopyAll) {
            if (shawdowCopyAll) {
                setup.ShadowCopyFiles = "true";
            }
            else {
                if (_shadowPaths.Count == 0) {
                    return;
                }
                string fullpath = "";
                foreach (string path in _paths) {
                    fullpath += path + Path.PathSeparator;
                }
                setup.ShadowCopyDirectories = fullpath;
            }
            if (_cacheDirectory.Length > 0) {
                setup.CachePath = _cacheDirectory;
            }
        }
        
        public AssemblyLoader Load() {
            pLoad(_shadowCopy);
            _remoteLoader = (RemoteLoader)_appDomain.CreateInstanceAndUnwrap(
                typeof( RemoteLoader).Assembly.FullName, typeof( RemoteLoader).FullName);
            return this;
        }
        public AssemblyLoader Unload() {
            pUnload();
            _remoteLoader = null;
            return this;
        }
        public bool CanCreate(Identifier identifier) {
            if (identifier.DoesExist(Identifier.ID_type) &&
                identifier.DoesExist(Identifier.ID_assembly)) {
                return true;
            }
            return false;
        }
        
        public ObjectType Instantiate<ObjectType>(Identifier identifier) where ObjectType : class {
            if (identifier.DoesExist(Identifier.ID_type) &&
                identifier.DoesExist(Identifier.ID_assembly)) {
                string typeIdentifier = identifier[Identifier.ID_type];
                string assemblyIdentifier = identifier[Identifier.ID_assembly];
                
                return (ObjectType)_appDomain.CreateInstanceAndUnwrap(assemblyIdentifier, typeIdentifier);
            }
            return default( ObjectType);
        }
        public override string ToString() {
            return new ToStringTracer()
                .Start(this)
                .Embedded(base.ToString())
                .Delegated(new ToStringTracerDelegate(
                               delegate(ToStringTracer instance) {
                                   if (_remoteLoader != null) {
                                       instance.Embedded(_remoteLoader.ToString());
                                   }
                               }))
                .End();
        }
    }
    
public class RemoteLoader : MarshalByRefObject {
    public RemoteLoader() {
    }
    public override string ToString() {
        return new ToStringTracer()
            .Start(this)
            .Variable("Base Directory", AppDomain.CurrentDomain.BaseDirectory)
            .Variable("Application directory", AppDomain.CurrentDomain.SetupInformation.ApplicationBase)
            .Variable("Application bin directory", AppDomain.CurrentDomain.SetupInformation.PrivateBinPath)
            .StartArray("Loaded Assemblies")
            .Delegated(new ToStringTracerDelegate(
                           delegate(ToStringTracer instance) {
                               foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies()) {
                                   instance.Variable("Assembly", assembly.FullName);
                               }
                           }))
            .EndArray()
            .End();
    }
}
}
