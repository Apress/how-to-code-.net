
namespace Devspace.Commons.Visitor {
    public interface ISupportVisitor {
        void Accept(IVisitor visitor);
    }
    
    public interface IVisitor {
        void Process< Type>(Type parameter);
    }
}
