﻿// one line to give the library's name and an idea of what it does.
// Copyright (C) 2005  Christian Gross devspace.com (christianhgross@yahoo.ca)
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Collections;
using Devspace.Commons.Tracer;

namespace Devspace.Commons.PipesFilters {
    
    #region IComponent definition
    public interface IComponent<ControlData> {
        bool Process(ControlData controldata);
    }
    #endregion
    
    #region Pipeline
    public interface IPipeline<T> {
        void AddLink(IComponent<T> link);
        bool Process(T t);
    }
    
    public enum OPTYPE { AND, OR };
    
    public class LinearPipeline<T> : IPipeline<T> {
        LinkedList<IComponent<T>> _links = new LinkedList<IComponent<T>>();
        OPTYPE _optype;
        public LinearPipeline() {
            _optype = OPTYPE.AND;
        }
        public LinearPipeline(OPTYPE type) {
            _optype = type;
        }
        
        public void AddLink(IComponent<T> link) {
            _links.AddLast(link);
        }
        
        public bool Process(T t) {
            bool result = false;
            try {
                
                if (_optype == OPTYPE.AND) {
                    result = true;
                    foreach (IComponent<T> link in _links) {
                        if (!link.Process(t)) {
                            result = false;
                            break;
                        }
                    }
                }
                else {
                    result = false;
                    foreach (IComponent<T> link in _links) {
                        if (link.Process(t)) {
                            result = true;
                            //break;
                        }
                    }
                }
            }
            catch (Exception ex) {
                System.Diagnostics.Debug.Write(ex.Message);
                result = false;
            }
            return result;
        }
    }
    #endregion
    
    #region IComponent Streaming Interfaces
    public interface InputStream< type> : IEnumerable {
        bool Available();
        type Read();
        ulong Read(out type[] data);
        ulong Read(out type[] data, ulong offset, ulong length);
        void Reset();
        void Skip(ulong offset);
    }
    
    public interface OutputStream<type> {
        void Flush();
        void Write(type data);
        void Write(type[] data);
        void Write(type[] data, ulong offset, ulong length);
    }
    
    public interface IStreamingControl< type> {
        InputStream< type> Input {
            get; set;
        }
        OutputStream< type> Output {
            get; set;
        }
        InputStream< type> FactoryInputStream();
        OutputStream< type> FactoryOutputStream();
    }
    
    public interface IComponentStreaming< type> : IComponent< IStreamingControl< type> > {
        bool Process(InputStream<type> input, OutputStream<type> output);
    }
    
    #endregion
    
    #region StreamingControlImpl
    public class StreamingControlImpl<type> : MarshalByRefObject, IStreamingControl< type> where type : new() {
        #region BridgedStreams implementation of InputStream, and OutputStream
        [Serializable]
        public class BridgedStreams : InputStream<type>, OutputStream<type> {
            type[] _buffer = new type[ 0 ];
            ulong _currIndex;
            ulong _afterLastWrittenIndex;
            
            public BridgedStreams() {
                _currIndex = 0;
                _afterLastWrittenIndex = 0;
            }
            
            public bool Available() {
                if (_currIndex < _afterLastWrittenIndex) {
                    return true;
                }
                else {
                    return false;
                }
            }
            public type Read() {
                if (_currIndex < _afterLastWrittenIndex) {
                    _currIndex++;
                    return _buffer[_currIndex - 1];
                }
                else {
                    throw new System.IO.EndOfStreamException();
                }
            }
            public ulong Read(out type[] data) {
                ulong size = _afterLastWrittenIndex - _currIndex;
                data = new type[size];
                for (ulong c1 = _currIndex; c1 < _afterLastWrittenIndex; c1++) {
                    data[c1 - _currIndex] = _buffer[c1];
                }
                return size;
            }
            public ulong Read(out type[] data, ulong offset, ulong length) {
                if (_afterLastWrittenIndex - offset > length) {
                    length = _afterLastWrittenIndex - offset;
                }
                data = new type[length];
                for (ulong c1 = offset; c1 < offset + length; c1++) {
                    data[c1 - offset] = _buffer[c1];
                }
                return length;
            }
            public void Reset() {
                _currIndex = 0;
            }
            public void Skip(ulong offset) {
                if (offset > _afterLastWrittenIndex) {
                    _currIndex = _afterLastWrittenIndex;
                }
                else {
                    _currIndex = offset;
                }
            }
            
            public void Flush() {
                _currIndex = 0;
                _afterLastWrittenIndex = 0;
                return;
            }
            private void Resize(ulong length) {
                if (length >= (ulong)_buffer.Length) {
                    type[] temp;
                    
                    if (_buffer.Length == 0) {
                        temp = new type[length * 2];
                    }
                    else {
                        temp = new type[_buffer.Length * 2];
                    }
                    for (int c1 = 0; c1 < _buffer.Length; c1++) {
                        temp[c1] = _buffer[c1];
                    }
                    _buffer = temp;
                }
            }
            public void Write(type data) {
                Resize(_currIndex + 1);
                _buffer[_currIndex] = data;
                _currIndex++;
                if (_currIndex > _afterLastWrittenIndex) {
                    _afterLastWrittenIndex = _currIndex;
                }
                return;
            }
            public void Write(type[] data) {
                foreach (type item in data) {
                    Write(item);
                }
                return;
            }
            public void Write(type[] data, ulong offset, ulong length) {
                Skip(offset);
                for (ulong c1 = 0; c1 < length; c1++) {
                    Write(data[c1]);
                }
                return;
            }
            public System.Collections.IEnumerator GetEnumerator() {
                for (ulong c1 = 0; c1 < _afterLastWrittenIndex; c1++) {
                    yield return _buffer[c1];
                }
            }
            public override string ToString() {
                return new ToStringTracer()
                    .Start(this)
                    .Variable("CurrIndex", _currIndex)
                    .Variable("LastWrittenIndex", _afterLastWrittenIndex)
                    .Variable("Buffer size", _buffer.Length)
                    .StartArray("Buffer content")
                    .Delegated(new ToStringTracerDelegate(delegate(ToStringTracer tracer) {
                                                              for (ulong c1 = 0; c1 < _afterLastWrittenIndex; c1++) {
                                                                  tracer.Variable("item", _buffer[c1].ToString());
                                                              }
                                                          }))
                    .EndArray()
                    .End();
            }
            
        }
        #endregion
        
        private InputStream< type> _inputStream;
        private OutputStream< type> _outputStream;
        public virtual InputStream< type> Input {
            get {
                return _inputStream;
            }
            set {
                _inputStream = value;
            }
        }
        public virtual OutputStream< type> Output {
            get {
                return _outputStream;
            }
            set {
                _outputStream = value;
            }
        }
        public virtual InputStream< type> FactoryInputStream() {
            return new BridgedStreams();
        }
        public virtual OutputStream< type> FactoryOutputStream() {
            return new BridgedStreams();
        }
    }
    
    public abstract class ComponentStreamingBase< type> : MarshalByRefObject, IComponentStreaming< type> where type : new() {
        public virtual bool Process(InputStream< type> input, OutputStream< type> output) {
            foreach (type element in input) {
                output.Write(element);
            }
            return true;
        }
        public bool Process(IStreamingControl< type> controlData) {
            if (controlData.Input == null) {
                controlData.Input = controlData.FactoryInputStream();
            }
            if (controlData.Output == null) {
                controlData.Output = controlData.FactoryOutputStream();
            }
            bool flag;
            flag = Process(controlData.Input, controlData.Output);
            
            if (controlData.Output is StreamingControlImpl<type>.BridgedStreams) {
                controlData.Input = (InputStream<type>)controlData.Output;
                controlData.Input.Reset();
            }
            else {
                controlData.Input = null;
            }
            controlData.Output = null;
            return flag;
        }
    }
    public abstract class InputSink<type> : ComponentStreamingBase<type> where type : new() {
        public abstract bool Process(OutputStream<type> output);
        
        public override bool Process(InputStream<type> input, OutputStream<type> output) {
            foreach (type item in input) {
                output.Write(item);
            }
            return Process(output);
        }
    }
    
    public abstract class OutputSink<type> : ComponentStreamingBase<type> where type : new() {
        public abstract bool Process(InputStream<type> input);
        
        public override bool Process(InputStream<type> input, OutputStream<type> output) {
            return Process(input);
        }
    }
    
    public abstract class ComponentInputIterator<type> : ComponentStreamingBase<type> where type : new() {
        public abstract bool Process(type item, OutputStream<type> output);
        public override bool Process(InputStream<type> input, OutputStream<type> output) {
            bool flag = false;
            foreach (type item in input) {
                if (Process(item, output))
                    flag = true;
            }
            return flag;
        }
    }
    #endregion
}

namespace PipesAndFilters {
    
    #region IComponent definition
    public interface IComponent<T> {
        bool Process(T t);
    }
    #endregion
    
    #region IComponent Streaming Interfaces
    public interface InputStream<T> : IEnumerable<T> {
        bool Available();
        T Read();
        ulong Read(out T[] Data, ulong offset, ulong length);
        void Reset();
        void Skip(ulong offset);
    }
    
    public interface OutputStream<T> {
        void Flush();
        void Write(T data);
        void Write(T[] Data);
        void Write(T[] Data, ulong offset, ulong length);
    }
    
    public interface IComponentStreaming<T> : IComponent<StreamingControlImpl<T>> where T : new() {
        bool Process(InputStream<T> input, OutputStream<T> output);
    }
    
    #endregion
    

    #region IStreamingControl
    
    public interface IStreamingControl<T> {
        InputStream<T> Input {
            get;
            set;
        }
        OutputStream<T> Output {
            get;
            set;
        }
        
        InputStream<T> FactoryInputStream();
        OutputStream<T> FactoryOutputStream();
    }
    public class StreamingControlImpl<T> : MarshalByRefObject, IStreamingControl<T> where T : new() {
        #region BridgedStreams implementation of InputStream, and OutputStream
        [Serializable]
        public class BridgedStreams : InputStream<T>, OutputStream<T> {
            T[] _buffer = new T[0];
            ulong _currIndex;
            ulong _afterLastWrittenIndex;
            
            public BridgedStreams() {
                _currIndex = 0;
                _afterLastWrittenIndex = 0;
            }
            
            public bool Available() {
                if (_currIndex < _afterLastWrittenIndex) {
                    return true;
                }
                else {
                    return false;
                }
            }
            public T Read() {
                if (_currIndex < _afterLastWrittenIndex) {
                    _currIndex++;
                    return _buffer[_currIndex - 1];
                }
                else {
                    throw new System.IO.EndOfStreamException();
                }
            }
            public ulong Read(out T[] data) {
                ulong size = _afterLastWrittenIndex - _currIndex;
                data = new T[size];
                for (ulong c1 = _currIndex; c1 < _afterLastWrittenIndex; c1++) {
                    data[c1 - _currIndex] = _buffer[c1];
                }
                return size;
            }
            public ulong Read(out T[] data, ulong offset, ulong length) {
                if (_afterLastWrittenIndex - offset > length) {
                    length = _afterLastWrittenIndex - offset;
                }
                data = new T[length];
                for (ulong c1 = offset; c1 < offset + length; c1++) {
                    data[c1 - offset] = _buffer[c1];
                }
                return length;
            }
            public void Reset() {
                _currIndex = 0;
            }
            public void Skip(ulong offset) {
                if (offset > _afterLastWrittenIndex) {
                    _currIndex = _afterLastWrittenIndex;
                }
                else {
                    _currIndex = offset;
                }
            }
            
            public void Flush() {
                _currIndex = 0;
                _afterLastWrittenIndex = 0;
                return;
            }
            private void Resize(ulong length) {
                if (length >= (ulong)_buffer.Length) {
                    T[] temp;
                    
                    if (_buffer.Length == 0) {
                        temp = new T[length * 2];
                    }
                    else {
                        temp = new T[_buffer.Length * 2];
                    }
                    for (int c1 = 0; c1 < _buffer.Length; c1++) {
                        temp[c1] = _buffer[c1];
                    }
                    _buffer = temp;
                }
            }
            public void Write(T data) {
                Resize(_currIndex + 1);
                _buffer[_currIndex] = data;
                _currIndex++;
                if (_currIndex > _afterLastWrittenIndex) {
                    _afterLastWrittenIndex = _currIndex;
                }
                return;
            }
            public void Write(T[] data) {
                foreach (T item in data) {
                    Write(item);
                }
                return;
            }
            public void Write(T[] data, ulong offset, ulong length) {
                Skip(offset);
                for (ulong c1 = 0; c1 < length; c1++) {
                    Write(data[c1]);
                }
                return;
            }
            IEnumerator System.Collections.IEnumerable.GetEnumerator() {
                return null;
            }

            public System.Collections.Generic.IEnumerator<T> GetEnumerator() {
                for (ulong c1 = 0; c1 < _afterLastWrittenIndex; c1++) {
                    yield return _buffer[c1];
                }
            }
            public override string ToString() {/*
                 MemoryTracer.Start(this);
                 MemoryTracer.Variable("CurrIndex", _currIndex);
                 MemoryTracer.Variable("LastWrittenIndex", _afterLastWrittenIndex);
                 MemoryTracer.Variable("Buffer size", _buffer.Length);
                 MemoryTracer.StartArray("Buffer content");
                 for (ulong c1 = 0; c1 < _afterLastWrittenIndex; c1++)
                 {
                 MemoryTracer.Variable("item", _buffer[c1].ToString());
                 }
                 MemoryTracer.EndArray();
                 return MemoryTracer.End();*/
                return "Bash";
            }
            
            
            #region IEnumerable<T> Members
            
            IEnumerator<T> IEnumerable<T>.GetEnumerator() {
                for (ulong c1 = 0; c1 < _afterLastWrittenIndex; c1++) {
                    yield return _buffer[c1];
                }
            }
            
            #endregion
        }
        #endregion
        
        private InputStream<T> _inputStream;
        private OutputStream<T> _outputStream;
        public virtual InputStream<T> Input {
            get {
                return _inputStream;
            }
            set {
                _inputStream = value;
            }
        }
        public virtual OutputStream<T> Output {
            get {
                return _outputStream;
            }
            set {
                _outputStream = value;
            }
        }
        public virtual InputStream<T> FactoryInputStream() {
            return new BridgedStreams();
        }
        public virtual OutputStream<T> FactoryOutputStream() {
            return new BridgedStreams();
        }
    }
    
    public abstract class StreamingComponentBase<T> : MarshalByRefObject, IComponentStreaming<T> where T : new() {
        public virtual bool Process(InputStream<T> input, OutputStream<T> output) {
            foreach (T t in input) {
                output.Write(t);
            }
            
            return true;
        }
        
        #region IComponent<StreamingControlImpl<T>> Members
        
        public bool Process(StreamingControlImpl<T> controlData) {
            if (controlData.Input == null)
                controlData.Input = controlData.FactoryInputStream();
            if (controlData.Output == null)
                controlData.Output = controlData.FactoryOutputStream();
            
            bool flag;
            flag = Process(controlData.Input, controlData.Output);
            
            if (controlData.Output is StreamingControlImpl<T>.BridgedStreams) {
                controlData.Input = (InputStream<T>)controlData.Output;
                controlData.Input.Reset();
            }
            else {
                controlData.Input = null;
            }
            controlData.Output = null;
            return flag;
        }
        
        #endregion
    }
    
    public abstract class InputSink<T> : StreamingComponentBase<T> where T : new() {
        public const bool isOutputSink = false;
        
        public abstract bool Process(OutputStream<T> output);
        
        public override bool Process(InputStream<T> input, OutputStream<T> output) {
            foreach (T t in input)
                output.Write(t);
            
            return Process(output);
        }
    }
    
    public abstract class OutputSink<T> : StreamingComponentBase<T> where T : new() {
        public const bool isOutputSink = true;
        
        public abstract bool Process(InputStream<T> input);
        
        public override bool Process(InputStream<T> input, OutputStream<T> output) {
            return Process(input);
        }
    }
    
    public abstract class ComponentInputIterator<T> : StreamingComponentBase<T> where T : new() {
        public const bool isOutputSink = false;
        
        public abstract bool Process(T item, OutputStream<T> output);
        
        public override bool Process(InputStream<T> input, OutputStream<T> output) {
            bool flag = false;
            foreach (T item in input) {
                if (Process(item, output))
                    flag = true;
            }
            return flag;
        }
    }
    
    #endregion
    
    #region Pipeline
    public interface IPipeline<T> {
        void AddLink(IComponent<T> link);
        bool Process(T t);
    }
    
    public enum OPTYPE { AND, OR };
    
    public class LinearPipeline<T> : IPipeline<T> where T : new() {
        LinkedList<IComponent<T>> _links = new LinkedList<IComponent<T>>();
        OPTYPE _optype;
        public LinearPipeline() {
            _optype = OPTYPE.AND;
        }
        public LinearPipeline(OPTYPE type) {
            _optype = type;
        }
        
        public void AddLink(IComponent<T> link) {
            _links.AddLast(link);
        }
        
        public bool Process(T t) {
            bool result = false;
            try {
                
                if (_optype == OPTYPE.AND) {
                    result = true;
                    foreach (IComponent<T> link in _links) {
                        if (!link.Process(t)) {
                            result = false;
                            break;
                        }
                    }
                }
                else {
                    result = false;
                    foreach (IComponent<T> link in _links) {
                        if (link.Process(t)) {
                            result = true;
                            //break;
                        }
                    }
                }
            }
            catch (Exception ex) {
                System.Diagnostics.Debug.Write(ex.Message);
                result = false;
            }
            return result;
        }
        public override string ToString() {
            throw new Exception("The method or operation is not implemented.");
        }
    }
    
    #endregion
    
    
    
    
}

